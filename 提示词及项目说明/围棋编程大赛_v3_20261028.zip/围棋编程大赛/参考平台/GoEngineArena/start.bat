@echo off
chcp 65001 >nul
cd /d "%~dp0"
title 围棋引擎竞技场
echo 正在启动 围棋引擎竞技场...
python server.py
pause

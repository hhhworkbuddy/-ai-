(function () {
  'use strict';

  var COLS = 'ABCDEFGHJKLMNOPQRSTUVWXYZ';

  /* ------------------------------------------------------------- DOM 引用 */
  var playView = document.getElementById('playView');
  var arenaView = document.getElementById('arenaView');
  var modeTabs = document.getElementById('modeTabs');
  var engineCountEl = document.getElementById('engineCount');
  var toastEl = document.getElementById('toast');

  var playCanvas = document.getElementById('playBoard');
  var arenaCanvas = document.getElementById('arenaBoard');

  var thinkingEl = document.getElementById('thinking');
  var playerYou = document.getElementById('playerYou');
  var playerAi = document.getElementById('playerAi');
  var youDot = document.getElementById('youDot');
  var aiDot = document.getElementById('aiDot');
  var youSide = document.getElementById('youSide');
  var aiSide = document.getElementById('aiSide');
  var aiName = document.getElementById('aiName');
  var youCap = document.getElementById('youCap');
  var aiCap = document.getElementById('aiCap');
  var turnText = document.getElementById('turnText');
  var moveText = document.getElementById('moveText');
  var komiHint = document.getElementById('komiHint');
  var logEl = document.getElementById('log');
  var logCount = document.getElementById('logCount');
  var logEmpty = document.getElementById('logEmpty');
  var scoreBox = document.getElementById('scoreBox');
  var resultBox = document.getElementById('resultBox');

  var newGameBtn = document.getElementById('newGameBtn');
  var passBtn = document.getElementById('passBtn');
  var undoBtn = document.getElementById('undoBtn');
  var scoreBtn = document.getElementById('scoreBtn');
  var resignBtn = document.getElementById('resignBtn');
  var sizeSeg = document.getElementById('sizeSeg');
  var colorSeg = document.getElementById('colorSeg');
  var levelRange = document.getElementById('levelRange');
  var levelLabel = document.getElementById('levelLabel');
  var playEngineSelect = document.getElementById('playEngineSelect');

  var arenaBlackName = document.getElementById('arenaBlackName');
  var arenaBlackElo = document.getElementById('arenaBlackElo');
  var arenaWhiteName = document.getElementById('arenaWhiteName');
  var arenaWhiteElo = document.getElementById('arenaWhiteElo');
  var arenaStatus = document.getElementById('arenaStatus');
  var arenaSmall = document.getElementById('arenaSmall');
  var arenaOverlay = document.getElementById('arenaOverlay');
  var progressBar = document.getElementById('progressBar');
  var progressText = document.getElementById('progressText');
  var arenaEnginesEl = document.getElementById('arenaEngines');
  var pickedCount = document.getElementById('pickedCount');
  var selectAllBtn = document.getElementById('selectAllBtn');
  var clearAllBtn = document.getElementById('clearAllBtn');
  var reloadEnginesBtn = document.getElementById('reloadEnginesBtn');
  var arenaSizeSeg = document.getElementById('arenaSizeSeg');
  var gamesSeg = document.getElementById('gamesSeg');
  var arenaLevel = document.getElementById('arenaLevel');
  var arenaLevelLabel = document.getElementById('arenaLevelLabel');
  var startArenaBtn = document.getElementById('startArenaBtn');
  var stopArenaBtn = document.getElementById('stopArenaBtn');
  var summaryBox = document.getElementById('summaryBox');
  var leaderBody = document.getElementById('leaderBody');
  var eloKHint = document.getElementById('eloKHint');
  var resetRatingsBtn = document.getElementById('resetRatingsBtn');
  var arenaLog = document.getElementById('arenaLog');
  var arenaLogEmpty = document.getElementById('arenaLogEmpty');
  var arenaLogCount = document.getElementById('arenaLogCount');

  /* ------------------------------------------------------------- 全局状态 */
  var engines = [];
  var settings = {};
  var selectedEngineIds = new Set();
  var selectionReady = false;
  var activeView = 'play';
  var eloCache = {};
  var eloFlash = {};
  var arenaPoll = null;
  var arenaPollBusy = false;
  var lastArenaMoveKey = '';
  var lastArenaGame = null;
  var lastArenaResultCount = -1;

  var playState = {
    size: 9,
    board: [],
    captures: { black: 0, white: 0 },
    turn: 'black',
    human_color: 'black',
    ai_color: 'white',
    level: 4,
    komi: 6.5,
    move_number: 0,
    last_move: null,
    history: [],
    finished: false,
    result: null,
    engine: { id: null, name: 'GNU Go', elo: 1000 }
  };

  var arenaState = {
    running: false,
    finished: false,
    stopped: false,
    error: null,
    total_games: 0,
    completed_games: 0,
    current: null,
    results: [],
    settings: {},
    summary: null
  };

  var busy = false;
  var toastTimer = null;
  var lastLogLen = -1;

  /* ============================================================ 棋盘视图 */
  function BoardView(canvas, options) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.options = options || {};
    this.interactive = !!this.options.interactive;
    this.model = { size: 9, board: [], lastMove: null, ghost: null };
    this.geom = null;
    this.hover = null;
    this.anim = null;
    this.rafId = null;
    this.dpr = 1;

    var self = this;
    canvas.addEventListener('click', function (ev) {
      if (!self.interactive || !self.options.onPoint) return;
      var p = self.hitTest(ev);
      if (p) self.options.onPoint(p);
    });
    canvas.addEventListener('mousemove', function (ev) {
      if (!self.interactive) return;
      var p = self.hitTest(ev);
      if ((!p && !self.hover) || (p && self.hover && p.x === self.hover.x && p.y === self.hover.y)) return;
      self.hover = p;
      self.schedule();
    });
    canvas.addEventListener('mouseleave', function () {
      if (self.hover) {
        self.hover = null;
        self.schedule();
      }
    });
  }

  BoardView.prototype.setModel = function (model, animateMove) {
    var sizeChanged = model.size !== this.model.size;
    this.model = model;
    if (sizeChanged) this.geom = null;
    if (animateMove && model.lastMove) {
      this.anim = { x: model.lastMove.x, y: model.lastMove.y, start: performance.now() };
    }
    this.schedule();
  };

  BoardView.prototype.buildGeometry = function (side) {
    var size = this.model.size;
    var pad = Math.max(24, side * 0.064);
    var cell = (side - pad * 2) / (size - 1);
    return {
      side: side,
      size: size,
      pad: pad,
      cell: cell,
      radius: Math.min(cell * 0.465, side * 0.052)
    };
  };

  BoardView.prototype.ensureGeometry = function () {
    var side = this.canvas.clientWidth;
    if (!side) return false;
    var dpr = Math.max(1, Math.min(2.5, window.devicePixelRatio || 1));
    var pixels = Math.round(side * dpr);
    if (this.canvas.width !== pixels || this.canvas.height !== pixels) {
      this.canvas.width = pixels;
      this.canvas.height = pixels;
    }
    this.dpr = dpr;
    if (!this.geom || this.geom.size !== this.model.size || Math.abs(this.geom.side - side) > 0.5) {
      this.geom = this.buildGeometry(side);
    }
    return true;
  };

  BoardView.prototype.resize = function () {
    this.geom = null;
    this.render(performance.now());
  };

  BoardView.prototype.schedule = function () {
    if (this.rafId !== null) return;
    var self = this;
    this.rafId = requestAnimationFrame(function tick(ts) {
      self.rafId = null;
      self.render(ts);
      if (self.anim && ts - self.anim.start < 240) {
        self.schedule();
      } else {
        self.anim = null;
      }
    });
  };

  BoardView.prototype.hitTest = function (ev) {
    if (!this.geom) return null;
    var rect = this.canvas.getBoundingClientRect();
    if (!rect.width) return null;
    var scale = this.geom.side / rect.width;
    var mx = (ev.clientX - rect.left) * scale;
    var my = (ev.clientY - rect.top) * scale;
    var x = Math.round((mx - this.geom.pad) / this.geom.cell);
    var y = Math.round((my - this.geom.pad) / this.geom.cell);
    if (x < 0 || y < 0 || x >= this.model.size || y >= this.model.size) return null;
    var dx = mx - (this.geom.pad + x * this.geom.cell);
    var dy = my - (this.geom.pad + y * this.geom.cell);
    if (Math.sqrt(dx * dx + dy * dy) > this.geom.cell * 0.62) return null;
    return { x: x, y: y };
  };

  BoardView.prototype.render = function (ts) {
    if (!this.ensureGeometry()) return;
    var ctx = this.ctx;
    var geom = this.geom;
    var side = geom.side;
    if (typeof ts !== 'number') ts = performance.now();

    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    ctx.clearRect(0, 0, side, side);
    this.drawWood(side);
    this.drawGrid();
    this.drawStars();
    this.drawCoords();
    this.drawStones(ts);
    this.drawLastMark();
    this.drawGhost();
  };

  BoardView.prototype.drawWood = function (side) {
    var ctx = this.ctx;
    var gradient = ctx.createLinearGradient(0, 0, side, side);
    gradient.addColorStop(0, '#e9cb93');
    gradient.addColorStop(0.38, '#dfb678');
    gradient.addColorStop(0.7, '#d3a465');
    gradient.addColorStop(1, '#c28f51');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, side, side);

    var seed = 20261021;
    function rnd() {
      seed = (seed * 16807) % 2147483647;
      return seed / 2147483647;
    }
    for (var i = 0; i < 76; i++) {
      var y = rnd() * side;
      ctx.beginPath();
      ctx.moveTo(-12, y);
      ctx.bezierCurveTo(
        side * 0.32, y + (rnd() - 0.5) * side * 0.07,
        side * 0.68, y + (rnd() - 0.5) * side * 0.07,
        side + 12, y + (rnd() - 0.5) * side * 0.05
      );
      ctx.strokeStyle = 'rgba(96,60,20,' + (0.016 + rnd() * 0.042).toFixed(3) + ')';
      ctx.lineWidth = 0.5 + rnd() * 2.1;
      ctx.stroke();
    }
    var vignette = ctx.createRadialGradient(side * 0.5, side * 0.44, side * 0.14, side * 0.5, side * 0.5, side * 0.8);
    vignette.addColorStop(0, 'rgba(255,242,210,0.16)');
    vignette.addColorStop(0.62, 'rgba(120,70,20,0.015)');
    vignette.addColorStop(1, 'rgba(62,32,6,0.24)');
    ctx.fillStyle = vignette;
    ctx.fillRect(0, 0, side, side);
  };

  BoardView.prototype.drawGrid = function () {
    var ctx = this.ctx;
    var geom = this.geom;
    var start = geom.pad;
    var end = geom.pad + geom.cell * (this.model.size - 1);
    ctx.save();
    ctx.strokeStyle = 'rgba(47,29,11,0.86)';
    ctx.lineWidth = Math.max(1, geom.cell * 0.028);
    for (var i = 0; i < this.model.size; i++) {
      var p = geom.pad + i * geom.cell;
      ctx.beginPath();
      ctx.moveTo(start, p);
      ctx.lineTo(end, p);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(p, start);
      ctx.lineTo(p, end);
      ctx.stroke();
    }
    ctx.lineWidth = Math.max(1.7, geom.cell * 0.06);
    ctx.strokeRect(start, start, end - start, end - start);
    ctx.restore();
  };

  BoardView.prototype.starPoints = function () {
    var size = this.model.size;
    var lines;
    if (size === 19) lines = [3, 9, 15];
    else if (size === 13) lines = [3, 9];
    else if (size === 9) lines = [2, 6];
    else {
      var edge = size >= 15 ? 3 : Math.floor(size / 3);
      lines = [edge, size - 1 - edge];
    }
    var points = [];
    for (var i = 0; i < lines.length; i++) {
      for (var j = 0; j < lines.length; j++) {
        points.push([lines[i], lines[j]]);
      }
    }
    if (size % 2 === 1) points.push([(size - 1) / 2, (size - 1) / 2]);
    return points;
  };

  BoardView.prototype.drawStars = function () {
    var ctx = this.ctx;
    var geom = this.geom;
    ctx.save();
    ctx.fillStyle = 'rgba(41,25,9,0.88)';
    var r = Math.max(2, geom.cell * 0.075);
    this.starPoints().forEach(function (pt) {
      ctx.beginPath();
      ctx.arc(geom.pad + pt[0] * geom.cell, geom.pad + pt[1] * geom.cell, r, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.restore();
  };

  BoardView.prototype.drawCoords = function () {
    var ctx = this.ctx;
    var geom = this.geom;
    var side = geom.side;
    var fontSize = Math.max(9.5, Math.min(geom.cell * 0.42, 14));
    var offset = geom.pad * 0.52;
    ctx.save();
    ctx.font = '500 ' + fontSize + 'px -apple-system, "Segoe UI", "Microsoft YaHei", sans-serif';
    ctx.fillStyle = 'rgba(74,47,17,0.76)';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (var x = 0; x < this.model.size; x++) {
      var cx = geom.pad + x * geom.cell;
      ctx.fillText(COLS[x], cx, offset);
      ctx.fillText(COLS[x], cx, side - offset);
    }
    for (var y = 0; y < this.model.size; y++) {
      var cy = geom.pad + y * geom.cell;
      var label = String(this.model.size - y);
      ctx.fillText(label, offset, cy);
      ctx.fillText(label, side - offset, cy);
    }
    ctx.restore();
  };

  function easeOut(t) {
    return 1 - Math.pow(1 - t, 3);
  }

  BoardView.prototype.drawStone = function (x, y, color, alpha, scale) {
    var ctx = this.ctx;
    var geom = this.geom;
    var r = geom.radius * (scale || 1);
    var cx = geom.pad + x * geom.cell;
    var cy = geom.pad + y * geom.cell;
    if (r <= 0.5) return;

    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.shadowColor = 'rgba(0,0,0,0.42)';
    ctx.shadowBlur = geom.cell * 0.22;
    ctx.shadowOffsetY = geom.cell * 0.085;

    var gradient = ctx.createRadialGradient(cx - r * 0.34, cy - r * 0.38, r * 0.08, cx, cy, r * 1.06);
    if (color === 'black') {
      gradient.addColorStop(0, '#6e6e6e');
      gradient.addColorStop(0.36, '#2c2c2c');
      gradient.addColorStop(1, '#050505');
    } else {
      gradient.addColorStop(0, '#ffffff');
      gradient.addColorStop(0.55, '#f4efe4');
      gradient.addColorStop(1, '#c9c0b0');
    }
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fillStyle = gradient;
    ctx.fill();

    ctx.shadowColor = 'transparent';
    ctx.lineWidth = Math.max(0.6, r * 0.045);
    ctx.strokeStyle = color === 'black' ? 'rgba(0,0,0,0.55)' : 'rgba(120,108,88,0.42)';
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(cx - r * 0.3, cy - r * 0.33, r * 0.3, 0, Math.PI * 2);
    ctx.fillStyle = color === 'black' ? 'rgba(255,255,255,0.10)' : 'rgba(255,255,255,0.65)';
    ctx.fill();
    ctx.restore();
  };

  BoardView.prototype.drawStones = function (ts) {
    var size = this.model.size;
    for (var y = 0; y < size; y++) {
      var row = this.model.board[y] || [];
      for (var x = 0; x < size; x++) {
        var v = row[x];
        if (v !== 'X' && v !== 'O') continue;
        var scale = 1;
        if (this.anim && this.anim.x === x && this.anim.y === y) {
          var t = Math.min(1, Math.max(0, (ts - this.anim.start) / 210));
          scale = 0.62 + 0.38 * easeOut(t);
        }
        this.drawStone(x, y, v === 'X' ? 'black' : 'white', 1, scale);
      }
    }
  };

  BoardView.prototype.drawLastMark = function () {
    var lm = this.model.lastMove;
    if (!lm || lm.x === null || lm.y === null) return;
    var ctx = this.ctx;
    var geom = this.geom;
    var cx = geom.pad + lm.x * geom.cell;
    var cy = geom.pad + lm.y * geom.cell;
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, geom.radius * 0.2, 0, Math.PI * 2);
    ctx.fillStyle = lm.color === 'black' ? 'rgba(255,244,228,0.92)' : '#c8553d';
    ctx.fill();
    ctx.restore();
  };

  BoardView.prototype.drawGhost = function () {
    var ghost = this.model.ghost;
    if (!this.interactive || !ghost || !this.hover) return;
    var row = this.model.board[this.hover.y];
    if (!row || row[this.hover.x] !== '.') return;
    this.drawStone(this.hover.x, this.hover.y, ghost, 0.36, 1);
  };

  var playBoard = new BoardView(playCanvas, {
    interactive: true,
    onPoint: function (point) {
      if (busy || playState.finished || playState.turn !== playState.human_color) return;
      if (playState.board[point.y][point.x] !== '.') {
        toast('这里已经有棋子了', true);
        return;
      }
      playBoard.hover = null;
      playBoard.setModel(playBoard.model);
      apiPlay('/api/move', { x: point.x, y: point.y });
    }
  });

  var arenaBoard = new BoardView(arenaCanvas, { interactive: false });

  /* ============================================================ 通用工具 */
  function levelName(n) {
    if (n <= 2) return '入门';
    if (n <= 4) return '初级';
    if (n <= 6) return '中级';
    if (n <= 8) return '高级';
    return '专家';
  }

  function toast(message, isError) {
    toastEl.textContent = message;
    toastEl.classList.toggle('error', !!isError);
    toastEl.classList.add('show');
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      toastEl.classList.remove('show');
    }, 2800);
  }

  function postJSON(path, body) {
    return fetch(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body || {})
    })
      .then(function (res) {
        return res.json().catch(function () { return {}; }).then(function (data) {
          if (!res.ok || data.error) {
            toast(data.error || '操作失败', true);
            return null;
          }
          return data;
        });
      })
      .catch(function () {
        toast('无法连接本地服务，请确认 server.py 正在运行', true);
        return null;
      });
  }

  function describeResult(raw, humanColor) {
    if (!raw) return '';
    var text = String(raw).trim();
    if (text === '0' || text === '0.0') return '和棋 · 双方平分秋色';
    var m = /^([BW])\+(.+)$/.exec(text);
    if (!m) return '结果：' + text;
    var side = m[1] === 'B' ? '黑棋' : '白棋';
    var humanWins = (m[1] === 'B') === (humanColor === 'black');
    var who = humanWins ? '你获胜' : '引擎获胜';
    if (m[2].toUpperCase() === 'R') return side + '中盘胜 · ' + who;
    return side + '胜 ' + m[2] + ' 目 · ' + who;
  }

  function describeScore(raw) {
    if (!raw) return '';
    var text = String(raw).trim();
    if (text === '0' || text === '0.0') return '形势判断：双方均势';
    var m = /^([BW])\+(.+)$/.exec(text);
    if (!m) return '形势判断：' + text;
    var side = m[1] === 'B' ? '黑棋' : '白棋';
    if (m[2].toUpperCase() === 'R') return '形势判断：' + side + '可中盘胜（引擎估算）';
    return '形势判断：' + side + '领先 ' + m[2] + ' 目（含贴目 ' + playState.komi + '）';
  }

  function escapeHtml(text) {
    return String(text == null ? '' : text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function engineById(id) {
    for (var i = 0; i < engines.length; i++) {
      if (engines[i].id === id) return engines[i];
    }
    return null;
  }

  /* ============================================================ 引擎数据 */
  function applyEngines(list, forceSelection) {
    if (!list) return;
    engines = list;

    var now = performance.now();
    list.forEach(function (item) {
      var previous = eloCache[item.id];
      if (typeof previous === 'number' && previous !== item.elo) {
        eloFlash[item.id] = { delta: Math.round((item.elo - previous) * 10) / 10, at: now };
      }
      eloCache[item.id] = item.elo;
    });

    engineCountEl.textContent = list.length + ' 个引擎';
    if (forceSelection) selectionReady = false;
    ensureSelection();
    renderEngineSelect();
    renderArenaEngines();
    renderLeaderboard();
    updateArenaControls();
  }

  function ensureSelection() {
    var available = engines.filter(function (e) { return e.available; }).map(function (e) { return e.id; });
    if (!selectionReady) {
      selectedEngineIds = new Set(available);
      selectionReady = true;
      return;
    }
    var kept = [];
    selectedEngineIds.forEach(function (id) {
      if (available.indexOf(id) !== -1) kept.push(id);
    });
    selectedEngineIds = new Set(kept);
  }

  function renderEngineSelect() {
    var previous = playEngineSelect.value;
    playEngineSelect.innerHTML = '';
    engines.forEach(function (item) {
      var option = document.createElement('option');
      option.value = item.id;
      option.textContent = item.name + ' · ' + Math.round(item.elo) + ' 分' + (item.available ? '' : '（不可用）');
      option.disabled = !item.available;
      playEngineSelect.appendChild(option);
    });
    var wanted = previous || (playState.engine && playState.engine.id);
    if (wanted && engineById(wanted)) {
      playEngineSelect.value = wanted;
    } else if (engines.length) {
      var firstAvailable = engines.filter(function (e) { return e.available; })[0];
      playEngineSelect.value = firstAvailable ? firstAvailable.id : engines[0].id;
    }
  }

  function renderArenaEngines() {
    arenaEnginesEl.innerHTML = '';
    engines.forEach(function (item) {
      var label = document.createElement('label');
      label.className = 'engine-pick' +
        (selectedEngineIds.has(item.id) ? ' checked' : '') +
        (item.available ? '' : ' unavailable');

      var checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.checked = selectedEngineIds.has(item.id);
      checkbox.disabled = !item.available || arenaState.running;

      var name = document.createElement('span');
      name.className = 'engine-pick-name';
      name.textContent = item.name;
      var desc = document.createElement('small');
      desc.textContent = item.description || (item.available ? 'GTP 引擎' : '引擎文件不可用');
      name.appendChild(desc);

      var elo = document.createElement('span');
      elo.className = 'engine-pick-elo';
      elo.textContent = Math.round(item.elo) + ' 分';

      checkbox.addEventListener('change', function () {
        if (checkbox.checked) selectedEngineIds.add(item.id);
        else selectedEngineIds.delete(item.id);
        label.classList.toggle('checked', checkbox.checked);
        updateArenaControls();
      });

      label.appendChild(checkbox);
      label.appendChild(name);
      label.appendChild(elo);
      arenaEnginesEl.appendChild(label);
    });

    pickedCount.textContent = selectedEngineIds.size + ' / ' + engines.length;
  }

  function renderLeaderboard() {
    leaderBody.innerHTML = '';
    engines.forEach(function (item) {
      var tr = document.createElement('tr');
      if (item.rank === 1) tr.className = 'top1';

      var rank = document.createElement('td');
      rank.className = 'col-rank';
      rank.textContent = item.rank;

      var nameCell = document.createElement('td');
      var name = document.createElement('span');
      name.className = 'rank-name';
      name.textContent = item.name;
      var sub = document.createElement('span');
      sub.className = 'rank-sub';
      sub.textContent = item.games + ' 局 · 胜率 ' + item.win_rate + '%';
      nameCell.appendChild(name);
      nameCell.appendChild(sub);

      var elo = document.createElement('td');
      elo.className = 'col-elo';
      elo.textContent = Math.round(item.elo);
      var flash = eloFlash[item.id];
      if (flash && performance.now() - flash.at < 9000 && flash.delta !== 0) {
        var badge = document.createElement('span');
        badge.className = 'elo-flash ' + (flash.delta > 0 ? 'up' : 'down');
        badge.textContent = (flash.delta > 0 ? '+' : '') + flash.delta;
        elo.appendChild(badge);
      }

      var record = document.createElement('td');
      record.className = 'col-record';
      record.textContent = item.wins + '-' + item.draws + '-' + item.losses;

      tr.appendChild(rank);
      tr.appendChild(nameCell);
      tr.appendChild(elo);
      tr.appendChild(record);
      leaderBody.appendChild(tr);
    });
  }

  /* ============================================================ 人机对弈 */
  function setBusy(value) {
    busy = value;
    thinkingEl.classList.toggle('show', value);
    if (value) playBoard.hover = null;
    updatePlayUI();
  }

  function apiPlay(path, body) {
    setBusy(true);
    return postJSON(path, body).then(function (data) {
      if (data) {
        if (data.engines) applyEngines(data.engines);
        if (data.state) applyPlayState(data.state);
      }
      setBusy(false);
      return data;
    }, function () {
      setBusy(false);
      return null;
    });
  }

  function applyPlayState(next) {
    if (!next) return;
    var animate = next.move_number > playState.move_number && !!next.last_move;
    var sizeChanged = next.size !== playState.size;
    playState = next;

    if (next.engine && next.engine.id) {
      var optionExists = Array.prototype.some.call(playEngineSelect.options, function (option) {
        return option.value === next.engine.id;
      });
      if (optionExists) playEngineSelect.value = next.engine.id;
    }

    playBoard.setModel({
      size: playState.size,
      board: playState.board,
      lastMove: playState.last_move,
      ghost: (!playState.finished && playState.turn === playState.human_color) ? playState.human_color : null
    }, animate);

    if (sizeChanged) playBoard.resize();
    updatePlayUI();
    renderPlayLog();
  }

  function updatePlayUI() {
    var human = playState.human_color;
    var ai = playState.ai_color;
    var yourTurn = !playState.finished && playState.turn === human;

    youDot.className = 'stone-dot ' + human;
    aiDot.className = 'stone-dot ' + ai;
    youSide.textContent = human === 'black' ? '执黑 · 先行' : '执白 · 后行';
    aiName.textContent = (playState.engine && playState.engine.name) || 'GNU Go';
    aiSide.textContent = (ai === 'black' ? '执黑' : '执白') + ' · 等级 ' + playState.level +
      ' · ' + Math.round(playState.engine && playState.engine.elo ? playState.engine.elo : 1000) + ' 分';
    youCap.textContent = playState.captures[human] || 0;
    aiCap.textContent = playState.captures[ai] || 0;

    turnText.textContent = playState.finished ? '对局结束' : (yourTurn ? '轮到你落子' : '引擎正在思考');
    moveText.textContent = '第 ' + playState.move_number + ' 手';
    komiHint.textContent = '贴目 ' + playState.komi;

    playerYou.classList.toggle('active', yourTurn);
    playerAi.classList.toggle('active', !playState.finished && !yourTurn);

    if (playState.finished && playState.result) {
      resultBox.hidden = false;
      resultBox.innerHTML = '<b>' + describeResult(playState.result, human) + '</b>';
      scoreBox.hidden = true;
    } else {
      resultBox.hidden = true;
      resultBox.innerHTML = '';
    }

    playCanvas.classList.toggle('disabled', busy || playState.finished || !yourTurn);
    updatePlayButtons();
  }

  function updatePlayButtons() {
    var canAct = !busy && !playState.finished;
    var hasHumanMove = (playState.history || []).some(function (h) {
      return h.color === playState.human_color;
    });
    passBtn.disabled = !canAct;
    undoBtn.disabled = !canAct || !hasHumanMove;
    scoreBtn.disabled = busy;
    resignBtn.disabled = !canAct;
    newGameBtn.disabled = busy;
    levelRange.disabled = busy;
    playEngineSelect.disabled = busy;
  }

  function renderPlayLog() {
    var items = playState.history || [];
    logEl.innerHTML = '';
    var fragment = document.createDocumentFragment();
    items.forEach(function (h, index) {
      var li = document.createElement('li');

      var num = document.createElement('span');
      num.className = 'num';
      num.textContent = index + 1;

      var dot = document.createElement('span');
      dot.className = 'dot ' + (h.color === 'black' ? 'black' : 'white');

      var coord = document.createElement('span');
      coord.className = 'coord';
      if (h.pass) coord.textContent = '停一手';
      else if (h.x !== null && h.x !== undefined) coord.textContent = COLS[h.x] + (playState.size - h.y);
      else coord.textContent = h.coord || '—';

      var who = document.createElement('span');
      who.className = 'who';
      who.textContent = h.color === playState.human_color ? '你' : 'AI';

      li.appendChild(num);
      li.appendChild(dot);
      li.appendChild(coord);
      li.appendChild(who);
      fragment.appendChild(li);
    });
    logEl.appendChild(fragment);
    logEmpty.hidden = items.length > 0;
    logCount.textContent = playState.move_number + ' 手';
    if (items.length !== lastLogLen) {
      logEl.scrollTop = logEl.scrollHeight;
      lastLogLen = items.length;
    }
  }

  /* ============================================================ 竞技场 */
  function applyArenaState(next) {
    if (!next) return;
    var previousCurrent = lastArenaGame;
    arenaState = next;
    updateArenaUI();

    var current = next.current;
    if (current) {
      lastArenaGame = current;
      var moveKey = current.game_no + ':' + current.moves + ':' +
        (current.last_move ? current.last_move.x + ',' + current.last_move.y : 'pass');
      var animate = moveKey !== lastArenaMoveKey && current.moves === (previousCurrent && previousCurrent.game_no === current.game_no ? previousCurrent.moves + 1 : 1);
      lastArenaMoveKey = moveKey;
      arenaBoard.setModel({
        size: next.settings.board_size || 9,
        board: current.board || [],
        lastMove: current.last_move,
        ghost: null
      }, animate);
      if (!arenaState.running || !arenaState.current) arenaBoard.resize();
    } else {
      arenaBoard.setModel({
        size: next.settings.board_size || 9,
        board: [],
        lastMove: null,
        ghost: null
      }, false);
      arenaBoard.resize();
    }

    renderArenaLog();

    if (next.running) {
      startArenaPolling();
    } else if (arenaPoll) {
      clearInterval(arenaPoll);
      arenaPoll = null;
    }
  }

  function updateArenaUI() {
    var state = arenaState;
    var current = state.current;
    var total = state.total_games || 0;
    var completed = state.completed_games || 0;

    var black = current ? engineById(current.black.id) : null;
    var white = current ? engineById(current.white.id) : null;

    if (current) {
      arenaBlackName.textContent = current.black.name;
      arenaWhiteName.textContent = current.white.name;
      arenaBlackElo.textContent = black ? Math.round(black.elo) + ' 分' : '—';
      arenaWhiteElo.textContent = white ? Math.round(white.elo) + ' 分' : '—';
    } else if (!state.running) {
      arenaBlackName.textContent = '等待开始';
      arenaWhiteName.textContent = '等待开始';
      arenaBlackElo.textContent = '—';
      arenaWhiteElo.textContent = '—';
    }

    if (state.running) {
      arenaStatus.textContent = current
        ? '第 ' + current.game_no + ' / ' + total + ' 局 · 对弈中'
        : '正在准备对局';
      arenaSmall.textContent = current ? ('已落 ' + current.moves + ' 手') : '循环赛 · 轮流执黑';
    } else if (state.finished) {
      arenaStatus.textContent = state.stopped ? '比赛已停止' : '比赛结束';
      arenaSmall.textContent = completed + ' / ' + total + ' 局已完成';
    } else {
      arenaStatus.textContent = '选择引擎后开始比赛';
      arenaSmall.textContent = '循环赛 · 轮流执黑';
    }

    var ratio = total > 0 ? Math.min(1, completed / total) : 0;
    progressBar.style.width = (ratio * 100).toFixed(1) + '%';
    progressText.textContent = completed + ' / ' + total + ' 局';

    arenaOverlay.classList.toggle('hidden', !!current || !!state.running);

    startArenaBtn.hidden = state.running;
    stopArenaBtn.hidden = !state.running;
    startArenaBtn.disabled = state.running || selectedEngineIds.size < 2;
    stopArenaBtn.disabled = !state.running;

    var cards = document.querySelectorAll('#arenaView .segmented button, #arenaLevel');
    Array.prototype.forEach.call(cards, function (el) {
      el.disabled = state.running;
    });

    if (state.finished && (state.error || state.summary || state.stopped)) {
      summaryBox.hidden = false;
      if (state.error) {
        summaryBox.innerHTML = '<b>比赛中断</b><span>' + escapeHtml(state.error) + '</span>';
      } else if (state.summary) {
        var rankingRows = (state.summary.ranking || []).map(function (row, index) {
          return '<div class="summary-rank">' +
            '<span class="sr-no">' + (index + 1) + '</span>' +
            '<span class="sr-name">' + escapeHtml(row.name) + '</span>' +
            '<span class="sr-elo">' + Math.round(row.elo) + '</span>' +
            '</div>';
        }).join('');
        summaryBox.innerHTML = '<b>' + (state.stopped ? '比赛已停止 · ' : '比赛结束 · ') +
          '当前榜首 ' + escapeHtml(state.summary.top.name) + '</b>' +
          rankingRows +
          '<span>共完成 ' + state.summary.games_played + ' 局，等级分与排名已更新</span>';
      } else {
        summaryBox.innerHTML = '<b>比赛已停止</b><span>尚未完成任何对局</span>';
      }
    } else if (state.running) {
      summaryBox.hidden = true;
    } else if (!state.finished) {
      summaryBox.hidden = true;
    }

    renderArenaEngines();
    renderLeaderboard();
    updateArenaControls();
  }

  function updateArenaControls() {
    pickedCount.textContent = selectedEngineIds.size + ' / ' + engines.length;
    startArenaBtn.disabled = arenaState.running || selectedEngineIds.size < 2;
    selectAllBtn.disabled = arenaState.running;
    clearAllBtn.disabled = arenaState.running;
    reloadEnginesBtn.disabled = arenaState.running;
    resetRatingsBtn.disabled = arenaState.running;
    eloKHint.textContent = 'K = ' + (settings.elo_k || 32);
  }

  function renderArenaLog() {
    var results = arenaState.results || [];
    arenaLog.innerHTML = '';
    var fragment = document.createDocumentFragment();
    results.forEach(function (record) {
      var li = document.createElement('li');

      var no = document.createElement('span');
      no.className = 'game-no';
      no.textContent = '#' + record.game_no;

      var matchup = document.createElement('span');
      matchup.className = 'matchup';
      var line = document.createElement('b');
      line.textContent = record.black.name + ' vs ' + record.white.name;
      var sub = document.createElement('span');
      sub.className = 'scoreline';
      var scoreText = record.score ? record.score : (record.reason === 'resign' ? '中盘胜' : '—');
      sub.textContent = scoreText + ' · ' + record.moves + ' 手';
      matchup.appendChild(line);
      matchup.appendChild(sub);

      var tag = document.createElement('span');
      if (record.winner === 'draw') {
        tag.className = 'winner-tag draw';
        tag.textContent = '和棋';
      } else {
        tag.className = 'winner-tag';
        tag.textContent = record.winner === 'black' ? '黑胜' : '白胜';
      }

      li.appendChild(no);
      li.appendChild(matchup);
      li.appendChild(tag);
      fragment.appendChild(li);
    });
    arenaLog.appendChild(fragment);
    arenaLogEmpty.hidden = results.length > 0;
    arenaLogCount.textContent = results.length + ' 局';
    if (results.length !== lastArenaResultCount) {
      arenaLog.scrollTop = arenaLog.scrollHeight;
      lastArenaResultCount = results.length;
    }
  }

  function fetchArenaState() {
    if (arenaPollBusy) return;
    arenaPollBusy = true;
    fetch('/api/arena/state')
      .then(function (res) { return res.json(); })
      .then(function (data) {
        if (!data) return;
        try {
          if (data.engines) applyEngines(data.engines);
          applyArenaState(data.state);
        } catch (err) {
          if (window.console && console.error) console.error('竞技场状态更新失败', err);
        }
      })
      .catch(function () {
        /* 网络短暂中断时保持轮询，等待恢复 */
      })
      .then(function () {
        arenaPollBusy = false;
      });
  }

  function startArenaPolling() {
    if (arenaPoll) return;
    fetchArenaState();
    arenaPoll = setInterval(fetchArenaState, 1200);
  }

  function stopArenaPolling() {
    if (arenaPoll) {
      clearInterval(arenaPoll);
      arenaPoll = null;
    }
  }

  /* ============================================================ 视图切换 */
  function switchView(view) {
    activeView = view;
    playView.hidden = view !== 'play';
    arenaView.hidden = view !== 'arena';
    Array.prototype.forEach.call(modeTabs.children, function (btn) {
      btn.classList.toggle('active', btn.getAttribute('data-view') === view);
    });
    try {
      localStorage.setItem('go-arena-view', view);
    } catch (err) { /* ignore */ }

    if (view === 'arena') {
      arenaBoard.resize();
      fetchArenaState();
    } else {
      playBoard.resize();
    }
  }

  /* ============================================================ 事件绑定 */
  Array.prototype.forEach.call(modeTabs.children, function (btn) {
    btn.addEventListener('click', function () {
      switchView(btn.getAttribute('data-view'));
    });
  });

  Array.prototype.forEach.call(sizeSeg.children, function (btn) {
    btn.addEventListener('click', function () {
      Array.prototype.forEach.call(sizeSeg.children, function (b) { b.classList.remove('active'); });
      btn.classList.add('active');
    });
  });

  Array.prototype.forEach.call(colorSeg.children, function (btn) {
    btn.addEventListener('click', function () {
      Array.prototype.forEach.call(colorSeg.children, function (b) { b.classList.remove('active'); });
      btn.classList.add('active');
    });
  });

  Array.prototype.forEach.call(arenaSizeSeg.children, function (btn) {
    btn.addEventListener('click', function () {
      if (arenaState.running) return;
      Array.prototype.forEach.call(arenaSizeSeg.children, function (b) { b.classList.remove('active'); });
      btn.classList.add('active');
    });
  });

  Array.prototype.forEach.call(gamesSeg.children, function (btn) {
    btn.addEventListener('click', function () {
      if (arenaState.running) return;
      Array.prototype.forEach.call(gamesSeg.children, function (b) { b.classList.remove('active'); });
      btn.classList.add('active');
    });
  });

  playEngineSelect.addEventListener('change', function () {
    var selected = engineById(playEngineSelect.value);
    if (selected) toast('已选择 ' + selected.name + '，点击「开始新对局」后生效');
  });

  levelRange.addEventListener('input', function () {
    levelLabel.textContent = levelName(parseInt(levelRange.value, 10));
  });

  levelRange.addEventListener('change', function () {
    apiPlay('/api/level', { level: parseInt(levelRange.value, 10) });
  });

  newGameBtn.addEventListener('click', function () {
    var sizeBtn = sizeSeg.querySelector('.active');
    var colorBtn = colorSeg.querySelector('.active');
    var body = {
      engine_id: playEngineSelect.value,
      size: parseInt(sizeBtn ? sizeBtn.getAttribute('data-size') : '9', 10),
      human_color: colorBtn ? colorBtn.getAttribute('data-color') : 'black',
      level: parseInt(levelRange.value, 10),
      komi: settings.komi || 6.5
    };
    scoreBox.hidden = true;
    resultBox.hidden = true;
    lastLogLen = -1;
    apiPlay('/api/new', body);
  });

  passBtn.addEventListener('click', function () {
    if (playState.finished || busy) return;
    apiPlay('/api/pass', {});
  });

  undoBtn.addEventListener('click', function () {
    if (playState.finished || busy) return;
    scoreBox.hidden = true;
    apiPlay('/api/undo', {});
  });

  scoreBtn.addEventListener('click', function () {
    if (busy) return;
    apiPlay('/api/score', {}).then(function (data) {
      if (!data) return;
      scoreBox.hidden = false;
      scoreBox.textContent = describeScore(data.score);
    });
  });

  resignBtn.addEventListener('click', function () {
    if (playState.finished || busy) return;
    if (!window.confirm('确定要认输吗？')) return;
    apiPlay('/api/resign', {});
  });

  arenaLevel.addEventListener('input', function () {
    arenaLevelLabel.textContent = levelName(parseInt(arenaLevel.value, 10));
  });

  startArenaBtn.addEventListener('click', function () {
    if (arenaState.running) return;
    var ids = Array.from(selectedEngineIds);
    if (ids.length < 2) {
      toast('至少选择两个引擎才能开始比赛', true);
      return;
    }
    var sizeBtn = arenaSizeSeg.querySelector('.active');
    var gamesBtn = gamesSeg.querySelector('.active');
    var body = {
      engine_ids: ids,
      size: parseInt(sizeBtn ? sizeBtn.getAttribute('data-size') : '9', 10),
      games_per_pair: parseInt(gamesBtn ? gamesBtn.getAttribute('data-games') : '2', 10),
      level: parseInt(arenaLevel.value, 10),
      komi: settings.komi || 6.5,
      max_moves: settings.max_moves || 400
    };
    startArenaBtn.disabled = true;
    postJSON('/api/arena/start', body).then(function (data) {
      if (!data) {
        updateArenaControls();
        return;
      }
      lastArenaMoveKey = '';
      lastArenaGame = null;
      lastArenaResultCount = -1;
      applyArenaState(data.state);
      startArenaPolling();
    });
  });

  stopArenaBtn.addEventListener('click', function () {
    if (!arenaState.running) return;
    postJSON('/api/arena/stop', {}).then(function (data) {
      if (data) applyArenaState(data.state);
    });
  });

  selectAllBtn.addEventListener('click', function () {
    engines.forEach(function (item) {
      if (item.available) selectedEngineIds.add(item.id);
    });
    renderArenaEngines();
    updateArenaControls();
  });

  clearAllBtn.addEventListener('click', function () {
    selectedEngineIds.clear();
    renderArenaEngines();
    updateArenaControls();
  });

  reloadEnginesBtn.addEventListener('click', function () {
    postJSON('/api/engines/reload', {}).then(function (data) {
      if (!data) return;
      applyEngines(data.engines, true);
      toast('引擎列表已刷新');
    });
  });

  resetRatingsBtn.addEventListener('click', function () {
    if (!window.confirm('确定将所有引擎等级分重置为 1000 并清空战绩吗？')) return;
    postJSON('/api/ratings/reset', {}).then(function (data) {
      if (!data) return;
      eloFlash = {};
      eloCache = {};
      applyEngines(data.engines);
      toast('等级分已重置为 1000');
    });
  });

  function handleResize() {
    playBoard.resize();
    if (!arenaView.hidden) arenaBoard.resize();
  }

  var resizeTimer = null;
  window.addEventListener('resize', function () {
    if (resizeTimer) clearTimeout(resizeTimer);
    resizeTimer = setTimeout(handleResize, 80);
  });

  if (window.ResizeObserver) {
    new ResizeObserver(function () {
      if (resizeTimer) clearTimeout(resizeTimer);
      resizeTimer = setTimeout(handleResize, 60);
    }).observe(playCanvas.parentElement);
    new ResizeObserver(function () {
      if (resizeTimer) clearTimeout(resizeTimer);
      resizeTimer = setTimeout(handleResize, 60);
    }).observe(arenaCanvas.parentElement);
  }

  /* ============================================================ 初始化 */
  function init() {
    var savedView = 'play';
    try {
      savedView = localStorage.getItem('go-arena-view') || 'play';
    } catch (err) { /* ignore */ }
    if (savedView !== 'arena') savedView = 'play';

    switchView(savedView);

    fetch('/api/engines')
      .then(function (res) { return res.json(); })
      .then(function (data) {
        settings = data.settings || {};
        arenaLevel.value = String(settings.level || 4);
        arenaLevelLabel.textContent = levelName(parseInt(arenaLevel.value, 10));
        levelRange.value = String(settings.level || 4);
        levelLabel.textContent = levelName(parseInt(levelRange.value, 10));
        komiHint.textContent = '贴目 ' + (settings.komi || 6.5);
        applyEngines(data.engines || []);
      })
      .catch(function () {
        toast('无法读取引擎列表，请重新启动服务', true);
      });

    fetch('/api/state')
      .then(function (res) { return res.json(); })
      .then(function (data) {
        if (data.engines) applyEngines(data.engines);
        if (data.state) {
          applyPlayState(data.state);
          levelRange.value = String(data.state.level);
          levelLabel.textContent = levelName(data.state.level);
          var sizeButton = sizeSeg.querySelector('[data-size="' + data.state.size + '"]');
          if (sizeButton) {
            Array.prototype.forEach.call(sizeSeg.children, function (b) { b.classList.remove('active'); });
            sizeButton.classList.add('active');
          }
          var colorButton = colorSeg.querySelector('[data-color="' + data.state.human_color + '"]');
          if (colorButton) {
            Array.prototype.forEach.call(colorSeg.children, function (b) { b.classList.remove('active'); });
            colorButton.classList.add('active');
          }
          if (data.state.engine && data.state.engine.id) {
            playEngineSelect.value = data.state.engine.id;
          }
        }
      })
      .catch(function () {
        toast('无法获取对局状态，请确认服务已启动', true);
      });

    fetch('/api/arena/state')
      .then(function (res) { return res.json(); })
      .then(function (data) {
        if (data.engines) applyEngines(data.engines);
        applyArenaState(data.state);
      })
      .catch(function () { /* ignore */ });
  }

  init();
})();

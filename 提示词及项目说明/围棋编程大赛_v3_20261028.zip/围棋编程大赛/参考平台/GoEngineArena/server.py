# -*- coding: utf-8 -*-
"""围棋引擎竞技场 —— 本地 Web 服务

功能：
  1. 人机对弈：从引擎列表中选择任意 GTP 引擎作为对手
  2. 引擎竞技场：多引擎循环赛、自对弈、一键开赛
  3. Elo 等级分：每个引擎初始 1000 分，按局更新并持久化排名
"""
import itertools
import json
import os
import re
import subprocess
import threading
import time
import webbrowser

from flask import Flask, jsonify, request, send_from_directory

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")
CONFIG_PATH = os.path.join(BASE_DIR, "engines.json")
DATA_DIR = os.path.join(BASE_DIR, "data")
RATINGS_PATH = os.path.join(DATA_DIR, "ratings.json")
PORT = int(os.environ.get("PORT", "8765"))
COLUMNS = "ABCDEFGHJKLMNOPQRSTUVWXYZ"
EDGE_PATHS = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]

app = Flask(__name__, static_folder=STATIC_DIR, static_url_path="/static")


class EngineError(Exception):
    pass


# --------------------------------------------------------------------- 配置
DEFAULT_SETTINGS = {
    "board_size": 9,
    "komi": 6.5,
    "level": 4,
    "games_per_pair": 2,
    "max_moves": 400,
    "elo_k": 32,
    "initial_elo": 1000,
}


def load_config():
    if not os.path.isfile(CONFIG_PATH):
        raise RuntimeError("缺少引擎配置文件 engines.json")
    with open(CONFIG_PATH, "r", encoding="utf-8") as fh:
        raw = json.load(fh)

    engines = []
    for item in raw.get("engines", []):
        eid = str(item.get("id") or item.get("name") or "").strip()
        if not eid:
            continue
        engines.append({
            "id": eid,
            "name": item.get("name") or eid,
            "description": item.get("description", ""),
            "path": item.get("path", ""),
            "args": item.get("args", ["--mode", "gtp", "--quiet"]),
            "cwd": item.get("cwd") or "",
            "supports_level": bool(item.get("supports_level", True)),
            "level": item.get("level"),
        })

    settings = dict(DEFAULT_SETTINGS)
    settings.update(raw.get("settings", {}))
    settings["board_size"] = int(settings["board_size"])
    settings["komi"] = float(settings["komi"])
    settings["level"] = int(settings["level"])
    settings["games_per_pair"] = int(settings["games_per_pair"])
    settings["max_moves"] = int(settings["max_moves"])
    settings["elo_k"] = float(settings["elo_k"])
    settings["initial_elo"] = float(settings["initial_elo"])
    return {"engines": engines, "settings": settings}


class EngineRegistry(object):
    def __init__(self):
        self.lock = threading.RLock()
        self.engines = []
        self.settings = dict(DEFAULT_SETTINGS)
        self.reload()

    def reload(self):
        with self.lock:
            config = load_config()
            self.engines = config["engines"]
            self.settings = config["settings"]
            return self.engines

    def get(self, engine_id):
        with self.lock:
            for engine in self.engines:
                if engine["id"] == engine_id:
                    return engine
            return None

    def all(self):
        with self.lock:
            return [dict(e) for e in self.engines]


# --------------------------------------------------------------- GTP 引擎
def friendly_error(msg):
    low = (msg or "").lower()
    if "illegal move" in low or "occupied" in low:
        return "这里不能落子（已有棋子或违反规则）"
    if "not your turn" in low:
        return "还没轮到这一方落子"
    return "引擎返回错误：" + (msg or "未知错误")


class GtpEngine(object):
    """单个 GTP 引擎进程。"""

    def __init__(self, cfg):
        self.cfg = cfg
        self.proc = None
        self.lock = threading.RLock()
        self.start()

    def start(self):
        path = self.cfg.get("path", "")
        if not path or not os.path.isfile(path):
            raise EngineError("找不到引擎文件：%s（请在 engines.json 中配置）" % (path or self.cfg.get("name")))
        args = [path] + list(self.cfg.get("args") or [])
        cwd = self.cfg.get("cwd") or os.path.dirname(path)
        self.proc = subprocess.Popen(
            args,
            cwd=cwd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            bufsize=0,
        )

    def is_alive(self):
        return self.proc is not None and self.proc.poll() is None

    def close(self):
        proc = self.proc
        self.proc = None
        if proc is None:
            return
        try:
            proc.stdin.write(b"quit\n")
            proc.stdin.flush()
        except Exception:
            pass
        try:
            proc.wait(timeout=2)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass

    def command(self, cmd):
        with self.lock:
            proc = self.proc
            if proc is None:
                raise EngineError("引擎尚未启动")
            if proc.poll() is not None:
                raise EngineError("引擎进程已退出：%s" % self.cfg.get("name"))
            try:
                proc.stdin.write((cmd + "\n").encode("utf-8"))
                proc.stdin.flush()
            except Exception as exc:
                raise EngineError("无法向引擎发送指令：%s" % exc)

            lines = []
            while True:
                raw = proc.stdout.readline()
                if not raw:
                    raise EngineError("引擎进程意外退出：%s" % self.cfg.get("name"))
                text = raw.decode("utf-8", "replace").rstrip("\r\n")
                if text == "":
                    break
                lines.append(text)

        status = None
        status_index = None
        for index, line in enumerate(lines):
            stripped = line.strip()
            if stripped.startswith("=") or stripped.startswith("?"):
                status = stripped
                status_index = index
                break
        if status is None:
            raise EngineError("引擎没有返回有效响应：%s" % self.cfg.get("name"))
        if status.startswith("?"):
            raise EngineError(friendly_error(status[1:].strip()))
        rest = [line for line in lines[status_index + 1:] if not line.strip().startswith("#")]
        return status[1:].strip(), rest


def parse_showboard(lines, size):
    board = [["." for _ in range(size)] for _ in range(size)]
    captures = {"black": 0, "white": 0}
    for line in lines:
        m = re.match(r"^\s*(\d+)\s", line)
        if m:
            row = int(m.group(1))
            if 1 <= row <= size:
                y = size - row
                for x in range(size):
                    idx = 2 + 2 * x + 1
                    ch = line[idx] if idx < len(line) else "."
                    if ch == "X":
                        board[y][x] = "X"
                    elif ch == "O":
                        board[y][x] = "O"
        cm = re.search(r"(BLACK|WHITE) \(([XO])\) has captured (\d+) stones", line)
        if cm:
            key = "black" if cm.group(1) == "BLACK" else "white"
            captures[key] = int(cm.group(3))
    return board, captures


def showboard(engine, size):
    _, lines = engine.command("showboard")
    return parse_showboard(lines, size)


def gtp_to_xy(coord, size):
    coord = (coord or "").strip().upper()
    if len(coord) < 2 or coord[0] not in COLUMNS:
        return None
    x = COLUMNS.index(coord[0])
    try:
        row = int(coord[1:])
    except ValueError:
        return None
    if x >= size or not (1 <= row <= size):
        return None
    return x, size - row


def opposite(color):
    return "white" if color == "black" else "black"


# --------------------------------------------------------------- 等级分
class Ratings(object):
    def __init__(self, path, initial_elo=1000.0):
        self.path = path
        self.initial_elo = initial_elo
        self.lock = threading.RLock()
        self.entries = {}
        self.load()

    def load(self):
        if not os.path.isfile(self.path):
            return
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                payload = json.load(fh)
            self.entries = dict(payload.get("engines", {}))
        except Exception:
            self.entries = {}

    def save(self):
        if not os.path.isdir(DATA_DIR):
            os.makedirs(DATA_DIR)
        payload = {"engines": self.entries, "updated_at": int(time.time())}
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=2)
        os.replace(tmp, self.path)

    def ensure(self, engines):
        with self.lock:
            changed = False
            for engine in engines:
                entry = self.entries.get(engine["id"])
                if entry is None:
                    entry = {}
                    self.entries[engine["id"]] = entry
                    changed = True
                if "elo" not in entry:
                    entry["elo"] = self.initial_elo
                for key in ("wins", "losses", "draws"):
                    if key not in entry:
                        entry[key] = 0
                entry["name"] = engine["name"]
                entry["games"] = entry["wins"] + entry["losses"] + entry["draws"]
            if changed:
                self.save()

    def _entry(self, engine_id, name):
        entry = self.entries.get(engine_id)
        if entry is None:
            entry = {"elo": self.initial_elo, "wins": 0, "losses": 0, "draws": 0, "games": 0, "name": name}
            self.entries[engine_id] = entry
        return entry

    def apply_result(self, black_id, black_name, white_id, white_name, winner, k):
        """winner: black / white / draw。返回双方分数变化。"""
        with self.lock:
            black = self._entry(black_id, black_name)
            white = self._entry(white_id, white_name)
            r_black = float(black["elo"])
            r_white = float(white["elo"])
            if winner == "black":
                score_black = 1.0
            elif winner == "white":
                score_black = 0.0
            else:
                score_black = 0.5

            expected_black = 1.0 / (1.0 + 10.0 ** ((r_white - r_black) / 400.0))
            delta = k * (score_black - expected_black)

            black["elo"] = round(r_black + delta, 1)
            white["elo"] = round(r_white - delta, 1)

            if winner == "black":
                black["wins"] += 1
                white["losses"] += 1
            elif winner == "white":
                white["wins"] += 1
                black["losses"] += 1
            else:
                black["draws"] += 1
                white["draws"] += 1
            black["games"] = black["wins"] + black["losses"] + black["draws"]
            white["games"] = white["wins"] + white["losses"] + white["draws"]
            black["name"] = black_name
            white["name"] = white_name
            self.save()
            return {
                black_id: round(delta, 1),
                white_id: round(-delta, 1),
            }

    def reset(self):
        with self.lock:
            for entry in self.entries.values():
                entry["elo"] = self.initial_elo
                entry["wins"] = 0
                entry["losses"] = 0
                entry["draws"] = 0
                entry["games"] = 0
            self.save()

    def snapshot(self, engines):
        """按等级分排序的引擎列表（含排名）。"""
        with self.lock:
            rows = []
            for engine in engines:
                entry = self.entries.get(engine["id"], {})
                wins = int(entry.get("wins", 0))
                losses = int(entry.get("losses", 0))
                draws = int(entry.get("draws", 0))
                games = wins + losses + draws
                rows.append({
                    "id": engine["id"],
                    "name": engine["name"],
                    "description": engine.get("description", ""),
                    "available": bool(engine.get("path") and os.path.isfile(engine["path"])),
                    "supports_level": engine.get("supports_level", True),
                    "elo": round(float(entry.get("elo", self.initial_elo)), 1),
                    "wins": wins,
                    "losses": losses,
                    "draws": draws,
                    "games": games,
                    "win_rate": round((wins + draws * 0.5) / games * 100, 1) if games else 0.0,
                })
            rows.sort(key=lambda r: (-r["elo"], -r["wins"], r["name"]))
            for index, row in enumerate(rows, 1):
                row["rank"] = index
            return rows


# --------------------------------------------------------------- 人机对弈
class HumanGame(object):
    def __init__(self, registry, ratings):
        self.registry = registry
        self.ratings = ratings
        self.lock = threading.RLock()
        self.engine = None
        self.engine_id = None
        self.size = registry.settings["board_size"]
        self.level = registry.settings["level"]
        self.komi = registry.settings["komi"]
        self.human_color = "black"
        self.ai_color = "white"
        self.board = [["." for _ in range(self.size)] for _ in range(self.size)]
        self.captures = {"black": 0, "white": 0}
        self.history = []
        self.turn = "black"
        self.finished = False
        self.result = None
        self.last_move = None
        self.consecutive_passes = 0

        engines = registry.all()
        available = [e for e in engines if e["path"] and os.path.isfile(e["path"])]
        first = available[0]["id"] if available else (engines[0]["id"] if engines else None)
        if first:
            try:
                self.new_game(first, self.size, self.level, "black", self.komi)
            except EngineError:
                self.engine = None

    # ------------------------------------------------------------- 引擎管理
    def _engine_for(self, engine_id):
        if self.engine is not None and self.engine_id == engine_id and self.engine.is_alive():
            return self.engine
        if self.engine is not None:
            self.engine.close()
            self.engine = None
        cfg = self.registry.get(engine_id)
        if cfg is None:
            raise EngineError("引擎不存在：%s" % engine_id)
        engine = GtpEngine(cfg)
        self.engine = engine
        self.engine_id = engine_id
        return engine

    def _sync(self):
        self.board, self.captures = showboard(self.engine, self.size)

    def _finish_by_score(self):
        raw = self.engine.command("final_score")[0].strip()
        self.result = raw or "0"
        self.finished = True

    def _apply_ai_move(self, coord):
        low = coord.strip().lower()
        if low == "resign":
            self.finished = True
            self.result = ("W" if self.ai_color == "black" else "B") + "+R"
            self.last_move = None
            return
        if low == "pass":
            self.history.append({"color": self.ai_color, "coord": "pass", "x": None, "y": None, "pass": True})
            self.last_move = None
            self.consecutive_passes += 1
            if self.consecutive_passes >= 2:
                self._finish_by_score()
            return

        xy = gtp_to_xy(coord, self.size)
        if xy is None:
            raise EngineError("无法解析引擎落子坐标：%s" % coord)
        self.history.append({
            "color": self.ai_color, "coord": coord.strip().upper(),
            "x": xy[0], "y": xy[1], "pass": False,
        })
        self.last_move = {"x": xy[0], "y": xy[1], "color": self.ai_color}
        self.consecutive_passes = 0

    def _ai_turn(self):
        coord = self.engine.command("genmove " + self.ai_color)[0]
        self._apply_ai_move(coord)

    # ------------------------------------------------------------- 操作
    def new_game(self, engine_id, size, level, human_color, komi):
        with self.lock:
            size = max(5, min(25, int(size)))
            level = max(1, min(10, int(level)))
            cfg = self.registry.get(engine_id)
            if cfg is None:
                raise EngineError("引擎不存在：%s" % engine_id)
            engine = self._engine_for(engine_id)

            self.size = size
            self.level = level
            self.komi = komi
            self.human_color = human_color if human_color in ("black", "white") else "black"
            self.ai_color = opposite(self.human_color)
            self.history = []
            self.turn = "black"
            self.finished = False
            self.result = None
            self.last_move = None
            self.consecutive_passes = 0
            self.captures = {"black": 0, "white": 0}

            engine.command("boardsize %d" % size)
            engine.command("clear_board")
            engine.command("komi %s" % komi)
            if cfg.get("supports_level", True):
                engine.command("level %d" % level)
            self._sync()

            if self.ai_color == "black":
                self._ai_turn()
                self._sync()
            self.turn = self.human_color

    def human_move(self, x, y):
        with self.lock:
            if self.finished:
                raise EngineError("对局已经结束，请开始新对局")
            if not (0 <= x < self.size and 0 <= y < self.size):
                raise EngineError("落子位置超出棋盘范围")
            if self.board[y][x] != ".":
                raise EngineError("这里已经有棋子了")
            coord = COLUMNS[x] + str(self.size - y)
            self.engine.command("play %s %s" % (self.human_color, coord))
            self.history.append({"color": self.human_color, "coord": coord, "x": x, "y": y, "pass": False})
            self.last_move = {"x": x, "y": y, "color": self.human_color}
            self.turn = self.ai_color
            self.consecutive_passes = 0
            self._sync()

            if not self.finished:
                self._ai_turn()
                self._sync()
                if not self.finished:
                    self.turn = self.human_color

    def human_pass(self):
        with self.lock:
            if self.finished:
                raise EngineError("对局已经结束，请开始新对局")
            self.engine.command("play %s pass" % self.human_color)
            self.history.append({"color": self.human_color, "coord": "pass", "x": None, "y": None, "pass": True})
            self.last_move = None
            self.turn = self.ai_color
            self.consecutive_passes += 1
            self._sync()

            if not self.finished:
                self._ai_turn()
                self._sync()
                if not self.finished:
                    self.turn = self.human_color

    def undo(self):
        with self.lock:
            if not self.history:
                raise EngineError("还没有可悔的棋")
            if not any(h["color"] == self.human_color for h in self.history):
                raise EngineError("还没有你的落子，无法悔棋")
            self.finished = False
            self.result = None
            self.consecutive_passes = 0
            while self.history:
                entry = self.history.pop()
                self.engine.command("undo")
                if entry["color"] == self.human_color:
                    break
            self._sync()
            if self.history:
                last = self.history[-1]
                if last["x"] is not None:
                    self.last_move = {"x": last["x"], "y": last["y"], "color": last["color"]}
                else:
                    self.last_move = None
            else:
                self.last_move = None
            self.turn = self.human_color

    def resign(self):
        with self.lock:
            if self.finished:
                raise EngineError("对局已经结束")
            self.finished = True
            self.result = ("W" if self.human_color == "black" else "B") + "+R"

    def score(self):
        with self.lock:
            return self.engine.command("final_score")[0].strip() or "0"

    def snapshot(self):
        with self.lock:
            cfg = self.registry.get(self.engine_id) if self.engine_id else None
            rating = self.ratings.snapshot(self.registry.all())
            elo = 1000.0
            for row in rating:
                if row["id"] == self.engine_id:
                    elo = row["elo"]
            return {
                "size": self.size,
                "board": [row[:] for row in self.board],
                "captures": dict(self.captures),
                "turn": "black" if self.finished else self.turn,
                "human_color": self.human_color,
                "ai_color": self.ai_color,
                "level": self.level,
                "komi": self.komi,
                "move_number": len(self.history),
                "last_move": self.last_move,
                "history": [dict(h) for h in self.history],
                "finished": self.finished,
                "result": self.result,
                "engine": {
                    "id": self.engine_id,
                    "name": cfg["name"] if cfg else "GNU Go",
                    "description": cfg.get("description", "") if cfg else "",
                    "elo": elo,
                },
            }


# --------------------------------------------------------------- 竞技场
class Arena(object):
    def __init__(self, registry, ratings):
        self.registry = registry
        self.ratings = ratings
        self.lock = threading.RLock()
        self.stop_event = threading.Event()
        self.thread = None
        self.state = self._idle_state()

    def _idle_state(self):
        return {
            "running": False,
            "finished": False,
            "stopped": False,
            "error": None,
            "total_games": 0,
            "completed_games": 0,
            "current": None,
            "results": [],
            "settings": {},
            "started_at": None,
            "finished_at": None,
            "summary": None,
        }

    def start(self, engine_ids, size, level, games_per_pair, max_moves, komi):
        with self.lock:
            if self.state["running"]:
                raise EngineError("比赛正在进行中")
            unique_ids = []
            for eid in engine_ids:
                if eid not in unique_ids:
                    unique_ids.append(eid)
            if len(unique_ids) < 2:
                raise EngineError("至少选择两个引擎才能开始比赛")

            engine_cfgs = {}
            for eid in unique_ids:
                cfg = self.registry.get(eid)
                if cfg is None:
                    raise EngineError("引擎不存在：%s" % eid)
                if not cfg.get("path") or not os.path.isfile(cfg["path"]):
                    raise EngineError("引擎文件不可用：%s" % cfg["name"])
                engine_cfgs[eid] = cfg

            games = []
            for first, second in itertools.combinations(unique_ids, 2):
                for index in range(games_per_pair):
                    if index % 2 == 0:
                        black_id, white_id = first, second
                    else:
                        black_id, white_id = second, first
                    games.append({
                        "game_no": len(games) + 1,
                        "black": black_id,
                        "white": white_id,
                    })

            self.state = self._idle_state()
            self.state.update({
                "running": True,
                "total_games": len(games),
                "settings": {
                    "board_size": size,
                    "level": level,
                    "games_per_pair": games_per_pair,
                    "max_moves": max_moves,
                    "komi": komi,
                    "engine_ids": unique_ids,
                },
                "started_at": int(time.time()),
            })
            self.stop_event.clear()
            self.thread = threading.Thread(
                target=self._run,
                args=(games, engine_cfgs, size, level, komi, max_moves),
                daemon=True,
            )
            self.thread.start()

    def stop(self):
        with self.lock:
            if not self.state["running"]:
                raise EngineError("当前没有正在进行的比赛")
            self.stop_event.set()

    # ------------------------------------------------------------- 比赛主循环
    def _run(self, games, engine_cfgs, size, level, komi, max_moves):
        processes = {}
        try:
            for eid, cfg in engine_cfgs.items():
                processes[eid] = GtpEngine(cfg)

            for game in games:
                if self.stop_event.is_set():
                    break
                black_id = game["black"]
                white_id = game["white"]
                black_name = engine_cfgs[black_id]["name"]
                white_name = engine_cfgs[white_id]["name"]

                if not processes[black_id].is_alive():
                    processes[black_id].close()
                    processes[black_id] = GtpEngine(engine_cfgs[black_id])
                if not processes[white_id].is_alive():
                    processes[white_id].close()
                    processes[white_id] = GtpEngine(engine_cfgs[white_id])

                with self.lock:
                    self.state["current"] = {
                        "game_no": game["game_no"],
                        "black": {"id": black_id, "name": black_name},
                        "white": {"id": white_id, "name": white_name},
                        "moves": 0,
                        "board": [["." for _ in range(size)] for _ in range(size)],
                        "last_move": None,
                        "status": "playing",
                    }

                result = self._play_game(
                    processes[black_id], processes[white_id],
                    engine_cfgs[black_id], engine_cfgs[white_id],
                    size, level, komi, max_moves,
                )
                if result is None:
                    break

                deltas = self.ratings.apply_result(
                    black_id, black_name, white_id, white_name,
                    result["winner"], self.registry.settings["elo_k"],
                )
                rows = self.ratings.snapshot(self.registry.all())
                elo_after = dict((row["id"], row["elo"]) for row in rows)

                record = {
                    "game_no": game["game_no"],
                    "black": {"id": black_id, "name": black_name},
                    "white": {"id": white_id, "name": white_name},
                    "winner": result["winner"],
                    "reason": result["reason"],
                    "score": result.get("score"),
                    "moves": result.get("moves", 0),
                    "elo_delta": deltas,
                    "elo_after": elo_after,
                }
                with self.lock:
                    self.state["completed_games"] += 1
                    self.state["results"].append(record)
                    if self.state["current"]:
                        self.state["current"]["status"] = "finished"

            with self.lock:
                self.state["running"] = False
                self.state["finished"] = True
                self.state["stopped"] = self.stop_event.is_set() and self.state["completed_games"] < self.state["total_games"]
                self.state["finished_at"] = int(time.time())
                if self.state["completed_games"] > 0:
                    rows = self.ratings.snapshot(self.registry.all())
                    participants = set(self.state["settings"].get("engine_ids", []))
                    ranking = [row for row in rows if row["id"] in participants]
                    if ranking:
                        self.state["summary"] = {
                            "top": {"id": ranking[0]["id"], "name": ranking[0]["name"], "elo": ranking[0]["elo"]},
                            "games_played": self.state["completed_games"],
                            "ranking": [
                                {
                                    "id": row["id"],
                                    "name": row["name"],
                                    "elo": row["elo"],
                                    "wins": row["wins"],
                                    "losses": row["losses"],
                                    "draws": row["draws"],
                                }
                                for row in ranking
                            ],
                        }
        except Exception as exc:
            with self.lock:
                self.state["error"] = str(exc)
                self.state["running"] = False
                self.state["finished"] = True
                self.state["finished_at"] = int(time.time())
        finally:
            for proc in processes.values():
                proc.close()
            with self.lock:
                if self.state["running"]:
                    self.state["running"] = False
                    self.state["finished"] = True

    def _setup(self, engine, cfg, size, komi, level):
        engine.command("boardsize %d" % size)
        engine.command("clear_board")
        engine.command("komi %s" % komi)
        if cfg.get("supports_level", True):
            engine_level = cfg.get("level") or level
            engine.command("level %d" % int(engine_level))

    def _play_game(self, black_engine, white_engine, black_cfg, white_cfg, size, level, komi, max_moves):
        self._setup(black_engine, black_cfg, size, komi, level)
        self._setup(white_engine, white_cfg, size, komi, level)

        turn = "black"
        passes = 0
        moves = 0
        last_move = None

        while moves < max_moves:
            if self.stop_event.is_set():
                return None
            mover = black_engine if turn == "black" else white_engine
            other = white_engine if turn == "black" else black_engine
            coord = mover.command("genmove " + turn)[0].strip()

            if coord.lower() == "resign":
                board, _ = showboard(black_engine, size)
                self._publish(board, moves, last_move, "finished")
                return {
                    "winner": opposite(turn),
                    "reason": "resign",
                    "score": None,
                    "moves": moves,
                }

            if coord.lower() == "pass":
                other.command("play %s pass" % turn)
                passes += 1
                last_move = None
            else:
                xy = gtp_to_xy(coord, size)
                if xy is None:
                    raise EngineError("引擎返回了无法解析的落子：%s" % coord)
                other.command("play %s %s" % (turn, coord.upper()))
                passes = 0
                last_move = {"x": xy[0], "y": xy[1], "color": turn}

            moves += 1
            board, _ = showboard(black_engine, size)
            self._publish(board, moves, last_move, "playing")

            if self.stop_event.is_set():
                return None
            if passes >= 2:
                break
            turn = opposite(turn)

        raw = black_engine.command("final_score")[0].strip()
        winner = "draw"
        match = re.match(r"^([BW])\+", raw.upper())
        if match:
            winner = "black" if match.group(1) == "B" else "white"
        self._publish(None, moves, last_move, "finished")
        return {"winner": winner, "reason": "score", "score": raw or "0", "moves": moves}

    def _publish(self, board, moves, last_move, status):
        with self.lock:
            current = self.state.get("current")
            if not current:
                return
            if board is not None:
                current["board"] = board
            current["moves"] = moves
            current["last_move"] = last_move
            current["status"] = status

    def snapshot(self):
        with self.lock:
            return json.loads(json.dumps(self.state))


# --------------------------------------------------------------- 全局对象
registry = EngineRegistry()
ratings = Ratings(RATINGS_PATH, registry.settings.get("initial_elo", 1000.0))
ratings.ensure(registry.all())
human_game = HumanGame(registry, ratings)
arena = Arena(registry, ratings)


def engine_rows():
    return ratings.snapshot(registry.all())


def parse_int(value, default, low, high):
    try:
        number = int(value)
    except (TypeError, ValueError):
        return default
    return max(low, min(high, number))


# --------------------------------------------------------------- 路由
@app.route("/")
def index():
    return send_from_directory(STATIC_DIR, "index.html")


@app.route("/api/engines")
def api_engines():
    return jsonify({"engines": engine_rows(), "settings": registry.settings})


@app.route("/api/engines/reload", methods=["POST"])
def api_engines_reload():
    try:
        with arena.lock:
            if arena.state["running"]:
                raise EngineError("比赛进行中，暂时不能刷新引擎列表")
        registry.reload()
        ratings.ensure(registry.all())
        return jsonify({"engines": engine_rows(), "settings": registry.settings})
    except EngineError as exc:
        return jsonify({"error": str(exc)}), 400
    except Exception as exc:
        return jsonify({"error": "读取 engines.json 失败：%s" % exc}), 400


@app.route("/api/state")
def api_state():
    return jsonify({"state": human_game.snapshot(), "engines": engine_rows()})


@app.route("/api/new", methods=["POST"])
def api_new():
    data = request.get_json(silent=True) or {}
    settings = registry.settings
    engine_id = data.get("engine_id") or (registry.all()[0]["id"] if registry.all() else None)
    size = parse_int(data.get("size"), settings["board_size"], 5, 25)
    level = parse_int(data.get("level"), settings["level"], 1, 10)
    komi = float(data.get("komi") or settings["komi"])
    human_color = data.get("human_color", "black")
    if human_color not in ("black", "white"):
        human_color = "black"
    try:
        human_game.new_game(engine_id, size, level, human_color, komi)
        return jsonify({"state": human_game.snapshot(), "engines": engine_rows()})
    except EngineError as exc:
        return jsonify({"error": str(exc)}), 400


@app.route("/api/move", methods=["POST"])
def api_move():
    data = request.get_json(silent=True) or {}
    try:
        x = int(data.get("x"))
        y = int(data.get("y"))
    except (TypeError, ValueError):
        return jsonify({"error": "落子坐标无效"}), 400
    try:
        human_game.human_move(x, y)
        return jsonify({"state": human_game.snapshot()})
    except EngineError as exc:
        return jsonify({"error": str(exc)}), 400


@app.route("/api/pass", methods=["POST"])
def api_pass():
    try:
        human_game.human_pass()
        return jsonify({"state": human_game.snapshot()})
    except EngineError as exc:
        return jsonify({"error": str(exc)}), 400


@app.route("/api/undo", methods=["POST"])
def api_undo():
    try:
        human_game.undo()
        return jsonify({"state": human_game.snapshot()})
    except EngineError as exc:
        return jsonify({"error": str(exc)}), 400


@app.route("/api/resign", methods=["POST"])
def api_resign():
    try:
        human_game.resign()
        return jsonify({"state": human_game.snapshot()})
    except EngineError as exc:
        return jsonify({"error": str(exc)}), 400


@app.route("/api/score", methods=["POST"])
def api_score():
    try:
        result = human_game.score()
        return jsonify({"state": human_game.snapshot(), "score": result})
    except EngineError as exc:
        return jsonify({"error": str(exc)}), 400


@app.route("/api/level", methods=["POST"])
def api_level():
    data = request.get_json(silent=True) or {}
    level = parse_int(data.get("level"), human_game.level, 1, 10)
    try:
        with human_game.lock:
            cfg = registry.get(human_game.engine_id) if human_game.engine_id else None
            if human_game.engine is None:
                raise EngineError("引擎尚未启动")
            if cfg and cfg.get("supports_level", True):
                human_game.engine.command("level %d" % level)
            human_game.level = level
        return jsonify({"state": human_game.snapshot()})
    except EngineError as exc:
        return jsonify({"error": str(exc)}), 400


@app.route("/api/arena/start", methods=["POST"])
def api_arena_start():
    data = request.get_json(silent=True) or {}
    settings = registry.settings
    engine_ids = data.get("engine_ids") or []
    size = parse_int(data.get("size"), settings["board_size"], 5, 25)
    level = parse_int(data.get("level"), settings["level"], 1, 10)
    games_per_pair = parse_int(data.get("games_per_pair"), settings["games_per_pair"], 1, 20)
    max_moves = parse_int(data.get("max_moves"), settings["max_moves"], 40, 2000)
    komi = float(data.get("komi") or settings["komi"])
    try:
        arena.start(engine_ids, size, level, games_per_pair, max_moves, komi)
        return jsonify({"state": arena.snapshot()})
    except EngineError as exc:
        return jsonify({"error": str(exc)}), 400


@app.route("/api/arena/stop", methods=["POST"])
def api_arena_stop():
    try:
        arena.stop()
        return jsonify({"state": arena.snapshot()})
    except EngineError as exc:
        return jsonify({"error": str(exc)}), 400


@app.route("/api/arena/state")
def api_arena_state():
    return jsonify({"state": arena.snapshot(), "engines": engine_rows()})


@app.route("/api/ratings/reset", methods=["POST"])
def api_ratings_reset():
    with arena.lock:
        if arena.state["running"]:
            return jsonify({"error": "比赛进行中，暂时不能重置等级分"}), 400
    ratings.reset()
    return jsonify({"engines": engine_rows()})


def open_browser(url):
    for path in EDGE_PATHS:
        if os.path.isfile(path):
            try:
                subprocess.Popen([path, url])
                return
            except Exception:
                pass
    webbrowser.open(url)


def main():
    url = "http://127.0.0.1:%d/" % PORT
    print("=" * 60)
    print("  围棋引擎竞技场  ·  Go Engine Arena")
    print("  引擎数量：%d" % len(registry.all()))
    for engine in registry.all():
        print("    - %s (%s)" % (engine["name"], engine["path"]))
    print("  地址：%s" % url)
    print("  按 Ctrl+C 结束服务")
    print("=" * 60)
    if os.environ.get("NO_BROWSER") != "1":
        threading.Timer(1.0, lambda: open_browser(url)).start()
    app.run(host="127.0.0.1", port=PORT, threaded=True, debug=False)


if __name__ == "__main__":
    main()
